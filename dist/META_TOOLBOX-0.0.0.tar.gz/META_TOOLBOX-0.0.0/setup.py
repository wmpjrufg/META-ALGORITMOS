from setuptools import setup

setup(
    	name = 'META_TOOLBOX',
    	version = '0.0.0',
	url='https://wmpjrufg.github.io/META_TOOLBOX/',
    	license='MIT License',
	author = 'Prof. Wanderlei M. Pereira Junior and Minning Eng. João Vitor Coelho Estrela',
    	author_email = 'wanderlei_junior@ufcat.edu.br',
    	packages = ['META_TOOLBOX']
    )

